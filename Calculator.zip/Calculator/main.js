let result = document.querySelector(".result");

function resultkey() {
    // let input = result.value;
    let sign = result.value.match(/[+\-*/%]/g);
    let number = result.value.split(/[+\-,*,/%]/g).map(Number);


    let total = number[0];
    for (let i = 0; i < sign.length; i++) {
        if (sign[i] === "+") {
            total += number[i + 1];
        } 
        else if (sign[i] === '-') {
            total -= number[i + 1];
        } 
        else if (sign[i] === '*') {
            total *= number[i + 1];
        } 
        else if (sign[i] === '/') {
            total /= number[i + 1];
        }
        else if (sign[i] === '%') {
            total %= number[i + 1];
        }
    }

    result.value = total;
}

function key(char) {
    result.value += char;
}

function clearkey() {
    result.value = '';
}

function backkey() {
    result.value = result.value.slice(0, -1);
}